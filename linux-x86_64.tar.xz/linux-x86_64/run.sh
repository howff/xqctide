#!/bin/bash
export PATH=$(pwd)
export LD_LIBRARY_PATH=$(pwd)
export HFILE_PATH=$(pwd)/tcd/harmonics-dwf-20091227-nonfree.tcd
export HLOGNUM=2
export HLOGDIR=$(pwd)
./xqct
